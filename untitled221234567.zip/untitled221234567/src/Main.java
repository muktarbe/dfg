// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {

      Book book1 = new Book("бктме бет ", 40, " чынгыз айтматов ");
      Book book2 = new Book(" толор кулаганда ", 40, " чынгыз айтматов ");
      Book book3 = new Book(" биринчи мугалим ", 40, " чынгыз айтматов ");
      Book book4 = new Book(" big men ", 40, " чынгыз айтматов ");
      Book book5 = new Book(" узак жол ", 40, " deputat ");

      Book [] books = {book1,book2,book3,book4,book5};
       Libraru libraru = new Libraru ();

        libraru ("dfgh","sdfghj",books);

    }
}